﻿

#include <iostream>
#include "book.h"
#include "printbook.h"
#include "shelf.h"
#include "BookShelf.h"

int main(int argc, char** argv)
{
    setlocale(0, "rus");
    book a;
    a.Print();
    int
   
}

